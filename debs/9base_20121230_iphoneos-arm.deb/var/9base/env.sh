#!/bin/sh
export PATH=/var/9base/bin:$PATH
