#ifndef _GLIB_OBJECT_H_
#define _GLIB_OBJECT_H_

/* empty */

#endif /* _GLIB_OBJECT_H_ */
