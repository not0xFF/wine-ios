#error In posixvala all classes must be [Compact]
typedef struct Error {
