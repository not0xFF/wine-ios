#ifndef _INCLUDE_CRT_EXTERNS_H_
#define _INCLUDE_CRT_EXTERNS_H_

extern char **environ;

#endif
